import streamlit as st
st.title('Hello from Streamlit in Docker!')
st.write('This is a simple web app running inside a Docker container.')